#include "LSTD_TYPES.h"
#include "LBIT_MATH.h"
#include "MUART_interface.h"
#include "MSPI_interface.h"
#include "MUART_private.h"
#include "MDIO_interface.h"

#define F_CPU 16000000UL
#include "util/delay.h"

int main(void)
{
	u8_t recv_var = 0;
	mdio_pinStatus(PORTB, PIN4, INPUT_FLOAT);
	mdio_pinStatus(PORTB, PIN5, INPUT_FLOAT);
	mdio_pinStatus(PORTB, PIN6, OUTPUT);
	mdio_pinStatus(PORTB, PIN7, INPUT_FLOAT);

	mspi_initSlave(MSPI_SAMPLE_R_SETUP_F, MSPI_PRE_32);
	
	mdio_pinStatus(PORTD, PIN1, OUTPUT);
	mdio_pinStatus(PORTD, PIN2, OUTPUT);
	mdio_pinStatus(PORTD, PIN3, OUTPUT);
	
    /* Replace with your application code */
    while (1) 
    {

		//_delay_ms(1000);
		if(MSPI_Recieve() == 'a')
		{
			mdio_setPinValue(PORTD, PIN2, HIGH);
		}
		else if(MSPI_Recieve() == 'b')
		{	
			mdio_setPinValue(PORTD, PIN2, LOW);
			
		}
		else if(MSPI_Recieve()== 'c')
		{	
			mdio_setPinValue(PORTD, PIN3, HIGH);

		
		}
		else if(MSPI_Recieve()=='d')
		{
			mdio_setPinValue(PORTD, PIN3, LOW);
		}
		else
		{
			mdio_setPinValue(PORTD, PIN3, LOW);
			mdio_setPinValue(PORTD, PIN2, LOW);
		
		}
		
    }
	
	return 0;
	
}

